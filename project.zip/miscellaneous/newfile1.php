<!DOCTYPE html>
<html>
<body>



<form method="post" action="http://localhost/project/show.php">
    <button type="submit">Continue</button>
</form>

</body>
</html>
      
            
            echo "<td>";
            echo $row['NAME'];
            echo "</td>";
            
            echo "<td>";
            echo $row['ROLE'];
            echo "</td>";
            
            echo "<td>";
            echo $row['DEPARTMENT'];
            echo "</td>";
            
            echo "<td>";
            echo $row['TASK'];
            echo "</td>";
            
            echo "<td>";
            echo $row['START'];
            echo "</td>";
            
            echo "<td>";
            echo $row['END'];
            echo "</td>";
            
