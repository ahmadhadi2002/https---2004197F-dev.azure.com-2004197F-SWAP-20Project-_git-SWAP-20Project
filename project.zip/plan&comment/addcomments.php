<?php
include 'config.php';
if (isset( $_POST['addcomments']) ){
    
    $start = $_REQUEST["start"];
    $end = $_REQUEST["end"];
    $username = $_REQUEST["username"];
    $department = $_REQUEST["department"];
    $comment = $_REQUEST["comment"];
    
    $query = $con->prepare("INSERT INTO `comments` (START, END, USERNAME, DEPARTMENT, COMMENT)
        VALUES ('$start','$end','$username','$department','$comment')");
    $result = $query->execute();
    if (!$result) {
        echo "Error";
        die();
    }
    else {
        echo "WORKS!!!! <br><br>";
        echo "User added to database <br>";
        echo "Starting Date: ".$start."<br>";
        echo "Ending Date: ".$end."<br>";
        echo "Username: ".$username."<br>";
        echo "Department: ".$department."<br>";
        echo "Comment: ".$comment."<br>";
        
    }
    echo "<form action='/project/plan&comment/getcomments.php' method='post'>";
    echo "<input type='hidden' name='start' value=$start>";
    echo "<input type='hidden' name='end' value=$end>";
    echo "<button name='getcomments'>Return to Comments</button></form>";
    
}
?>