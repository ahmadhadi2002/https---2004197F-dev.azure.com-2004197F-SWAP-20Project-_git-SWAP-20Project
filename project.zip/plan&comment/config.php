<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "project";

$con = mysqli_connect($server, $user, $pass, $database);

?>