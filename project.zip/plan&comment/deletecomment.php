<?php
include 'config.php';

if (isset($_POST['deletecomment'])){
    
    $start = $_REQUEST['start'];
    $end = $_REQUEST['end'];
    $id = $_POST['deletecomment'];
    
    $query = $con->prepare("DELETE FROM `comments` WHERE ID='$id'");
    $result = $query->execute();
    if (!$result) {
        echo "Error";
        die();
    }
    
    
    echo "COMMENT DELETED";
    echo "<br><br>";
    echo "ID: ".$id."<br><br>";
   
    
    echo "<form action='/project/plan&comment/getcomments.php' method='post'>";
    echo "<input type='hidden' name='start' value=$start>";
    echo "<input type='hidden' name='end' value=$end>";
	echo "<button name='getcomments'>Return to Comments</button></form>";
}
?>
