<html>
<form action="addcomments.php" method="post">
Username
	<input type="text" name="username"><br><br>
Department
	<input type="text" name="department"><br><br>
Comment
	<input type="text" name="comment"><br><br>
<input type='hidden' name='start' value=<?php  echo $_REQUEST["start"]?>>
<input type='hidden' name='end' value=<?php echo $_REQUEST["end"]?>>
<input type="submit" name="addcomments"  >


</form>
</html>
<?php
include 'config.php';
if (isset( $_POST['getcomments']) ){
    
    $start=$_REQUEST["start"];
    $end=$_REQUEST["end"];
    $query = $con->prepare("SELECT * FROM `comments` WHERE START=? && END=?");
    $query->bind_param('ss',$start,$end);
    if ($query->execute()){
        echo "Query executed. Comments received<br>";
        $query->bind_result($id, $start, $end, $username, $department, $comment, $timestamp);
        
    }else{
        echo "Error executing query.";
    }
    
    echo "==============Comments==================<br><br>";
    
    while ($query->fetch()){

        echo "ID: ";
        echo $id;
        echo "<br>";
        echo "Username: ";
        echo $username;
        echo "<br>";
        echo "Comment: ";
        echo $comment;
        echo "<br>";
        echo "Department: ";
        echo $department;
        echo "<br>";
        echo "Timestamp: ";
        echo $timestamp;
       
        //making of update and delete buttons//
        echo "<form action='/project/plan&comment/updatecommentpage.php' method='get'>";
        echo "<input type='hidden' name='start' value=$start>";
        echo "<input type='hidden' name='end' value=$end>";
        echo "<button id='updatecomment' name='updatecomment' value=$id>Update</button></form><nobr>";
        echo "<form action='/project/plan&comment/deletecomment.php' method='post'>";
        echo "<input type='hidden' name='start' value=$start>";
        echo "<input type='hidden' name='end' value=$end>";
        echo "<button id='deletecomment' name='deletecomment' value=$id>Delete</button></form>";
        echo "<br><br>";
    }
}
?>