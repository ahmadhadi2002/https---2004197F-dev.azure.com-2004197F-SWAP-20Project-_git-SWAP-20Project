<?php
include 'config.php';

if (isset($_POST['updatecomment1'])){
    
    $id = $_POST['updatecomment1'];
       
            $start = $_REQUEST["start"];
            $end = $_REQUEST["end"];
            $username = $_REQUEST["username"];
            $department = $_REQUEST["department"];
            $comment = $_REQUEST["comment"];
        
            $query = $con->prepare("UPDATE `comments` SET START=?, END=?, USERNAME=?, DEPARTMENT=?, COMMENT=? WHERE ID='$id'");
            $query->bind_param("sssss", $start, $end, $username, $department, $comment);
            $result = $query->execute();
            if (!$result) {
                echo "Error";
                die();
            }
            
            echo "UPDATE SUCCESSFUL";
            echo "<form action='/project/plan&comment/getcomments.php' method='post'>";
            echo "<input type='hidden' name='start' value=$start>";
            echo "<input type='hidden' name='end' value=$end>";
            echo "<button name='getcomments'>Return to Comments</button></form>";
        }

?>


