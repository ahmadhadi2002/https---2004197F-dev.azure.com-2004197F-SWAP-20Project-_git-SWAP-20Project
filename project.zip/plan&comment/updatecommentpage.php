<?php 
$start = $_REQUEST['start'];
$end = $_REQUEST['end'];
    $id = $_GET["updatecomment"];
    echo "<form action='/project/plan&comment/updatecomment.php' method='post'>";
    echo "Username";
    echo "<input type='text' name='username'><br><br>";
    echo "Department";
    echo "<input type='text' name='department'><br><br>";
    echo "Comment";
    echo "<input type='text' name='comment'><br><br>";
    echo "<input type='hidden' name='start' value=$start>";
    echo "<input type='hidden' name='end' value=$end>";
    echo "<button id='updatecomment1' name='updatecomment1' value='$id'>Submit</button></form>";
?>


