<?php
$db_hostname="127.0.0.1";
$db_username="root";
$db_password="";

$db_database="project";


?>