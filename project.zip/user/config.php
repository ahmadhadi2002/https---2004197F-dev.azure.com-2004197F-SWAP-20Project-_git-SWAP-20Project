<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "project";

$conn = mysqli_connect($server, $user, $pass, $database);

$base_url = "localhost/project/user/";
$myemail = "swapproject21@gmail.com";

?>